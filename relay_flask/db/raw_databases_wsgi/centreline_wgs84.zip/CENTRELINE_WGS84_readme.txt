CENTRELINE_WGS84_readme
 

Column name  
======================================
GEO_ID = unique geographic identifier
LFN_ID = Steet Name ID
LF_NAME = Full street name
ADDRESS_L = Address Range on the left side of the street
ADDRESS_R = Address Range on the right side of the street
OE_FLAG_L = Even/Odd address numbers on left side of street
OE_FLAG_R = Even/Odd address numbers on right side of street
LONUML = Lowest address number for left side of the street segment
HINUML = Highest address number for left side of the street segment
LONUMR = Lowest address number for right side of the street segment
HINUMR = Highest address number for right side of the street segment
FNODE = FROM_INTERSECTION_ID
TNODE = TO_INTERSECTION_ID
FCODE = street classification
FCODE_DESC = description of the street classification
JURIS_CODE = street jurisdiction (ownership)
OBJECTID = system genertaed unique Id
